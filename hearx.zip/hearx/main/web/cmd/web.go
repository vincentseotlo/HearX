/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>
*/
package cmd

import (
	"context"
	"github.com/gin-gonic/gin"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"go.uber.org/fx"
	"hearx/example/middleware"
	"hearx/example/routes"
	"net/http"
	"time"
)

// webCmd represents the web command
var webCmd = &cobra.Command{
	Use:   "web",
	Short: "starts the front end for REST API.",
	Long:  `starts the front end for REST API. It does not return.`,
	Run: func(cmd *cobra.Command, args []string) {
		fx.New(
			fx.Provide(NewHTTPServer),
			fx.Invoke(func(*http.Server) {}),
		).Run()
	},
}

func NewHTTPServer(lc fx.Lifecycle) *http.Server {
	router := gin.Default()
	srv := &http.Server{
		Addr:    Cfg.HearXWebServer,
		Handler: router,
	}
	lc.Append(fx.Hook{
		OnStart: func(ctx context.Context) error {
			router.GET("/ping", func(c *gin.Context) {
				c.JSON(http.StatusOK, gin.H{
					"message": "pong",
				})
			})

			auth := router.Group("/auth")
			tasks := router.Group("/task")

			tasks.Use(middleware.AuthCheck)

			routes.AddAuthRoutes(auth)
			routes.AddTasksRoutes(tasks)
			go func() {
				if err := srv.ListenAndServe(); err != nil {
					log.Info("Failed to run web server ", err)
				}
			}()
			return nil
		},
		OnStop: func(ctx context.Context) error {
			log.Info("Gracefully stopping Web server")
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			srv.Shutdown(ctx)
			return nil
		},
	})
	return srv
}
func init() {
	rootCmd.AddCommand(webCmd)
}
