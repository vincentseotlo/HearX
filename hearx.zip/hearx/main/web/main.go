/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>

*/
package main

import "hearx/example/web/cmd"

func main() {
	cmd.Execute()
}
