package models

// Config - We store all configs here
type Config struct {
	MysqlDSN       string
	HearXServer    string
	HearXWebServer string
}
