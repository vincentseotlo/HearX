package models

import "gorm.io/gorm"

// User model
type User struct {
	gorm.Model
	Id           int64  `gorm:"primaryKey"`
	FullName     string `json:"full_name"`
	Email        string `json:"email"`
	Password     string `json:"password"`
	Token        string
	TokenExpires int64
}
