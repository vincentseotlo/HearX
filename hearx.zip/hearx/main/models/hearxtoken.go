package models

// HearXToken representation of the custom auth token
type HearXToken struct {
	Token  string
	Base   string
	UserId int64
}
