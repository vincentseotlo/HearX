package models

import "gorm.io/gorm"

// Task model
type Task struct {
	gorm.Model
	Id      int64  `json:"id" bson:"id" gorm:"primaryKey"`
	UserId  int64  `json:"user_id" bson:"user_id"` // referential integrity???
	Title   string `json:"title" bson:"title"`
	DueTime int64  `json:"due_time" bson:"due_time"`
	Done    bool   `json:"done" bson:"done"`
}
