package cmd

import (
	"context"
	"fmt"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"google.golang.org/grpc"
	"hearx/example/hearxproto"
)

// completeCmd represents the complete command
var completeCmd = &cobra.Command{
	Use:   "complete",
	Short: "Set task as complete.",
	Long:  `Set task as complete.`,
	Run: func(cmd *cobra.Command, args []string) {
		resp, err := CompleteTask(Token, TaskId)
		if err != nil {
			log.Fatal(err)
		}

		fmt.Printf("Response: %v\n", resp)
	},
}

func init() {
	clientCmd.AddCommand(completeCmd)
	completeCmd.Flags().StringVarP(&Token, "token", "t", "", "-t HearX-Token")
	completeCmd.Flags().Int64VarP(&TaskId, "taskId", "d", -1, "-d task_id")
	_ = completeCmd.MarkFlagRequired("token")
	_ = completeCmd.MarkFlagRequired("taskId")
}

func CompleteTask(userId string, taskId int64) (*hearxproto.StatusResponse, error) {
	opts := grpc.WithInsecure()
	conn, err := grpc.Dial(Cfg.HearXServer, opts)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	var data hearxproto.TaskRequest
	data.UserId = userId
	data.TaskId = taskId
	client := hearxproto.NewTodoServiceClient(conn)

	resp, err := client.CompleteTask(context.Background(), &data)
	return resp, err
}
