package cmd

import (
	"context"
	"fmt"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"google.golang.org/grpc"
	"hearx/example/hearxproto"
)

var (
	TaskId int64
)

// deleteCmd represents the delete command
var deleteCmd = &cobra.Command{
	Use:   "delete",
	Short: "Delete given task_id from storage",
	Long:  `Delete given task_id from storage`,
	Run: func(cmd *cobra.Command, args []string) {
		resp, err := DeleteTask(Token, TaskId)
		if err != nil {
			log.Fatal(err)
		}

		fmt.Printf("Response: %v\n", resp)
	},
}

func init() {
	clientCmd.AddCommand(deleteCmd)
	deleteCmd.Flags().StringVarP(&Token, "token", "t", "", "-t HearX-Token")
	deleteCmd.Flags().Int64VarP(&TaskId, "taskId", "d", -1, "-d task_id")
	_ = deleteCmd.MarkFlagRequired("token")
	_ = deleteCmd.MarkFlagRequired("taskId")
}

func DeleteTask(userId string, taskId int64) (*hearxproto.StatusResponse, error) {
	opts := grpc.WithInsecure()
	conn, err := grpc.Dial(Cfg.HearXServer, opts)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	var data hearxproto.TaskRequest
	data.UserId = userId
	data.TaskId = taskId
	client := hearxproto.NewTodoServiceClient(conn)

	resp, err := client.DeleteTask(context.Background(), &data)
	return resp, err
}
