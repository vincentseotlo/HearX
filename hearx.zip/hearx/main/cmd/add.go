package cmd

import (
	"context"
	"fmt"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"google.golang.org/grpc"
	"hearx/example/hearxproto"
)

var (
	Title string
	Due   int64 = 1
)

// addCmd represents the add command
var addCmd = &cobra.Command{
	Use:   "add",
	Short: "Add a new Todo/task to storage.",
	Long:  `Add a new Todo/task to storage.`,
	Run: func(cmd *cobra.Command, args []string) {
		resp, err := AddTask(Token, Title, Due)
		if err != nil {
			log.Fatal(err)
		}

		fmt.Printf("Response: %v\n", resp)
	},
}

func init() {
	clientCmd.AddCommand(addCmd)
	addCmd.Flags().StringVarP(&Token, "token", "t", "", "-t HearX-Token")
	addCmd.Flags().StringVarP(&Title, "title", "p", "", "-p title")
	addCmd.Flags().Int64VarP(&Due, "due", "d", 1, "-d 3 ... (Due in 3 days)")
	_ = addCmd.MarkFlagRequired("token")
	_ = addCmd.MarkFlagRequired("title")
}

func AddTask(userId string, title string, due int64) (*hearxproto.StatusResponse, error) {
	opts := grpc.WithInsecure()
	conn, err := grpc.Dial(Cfg.HearXServer, opts)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	var task hearxproto.Task
	task.DueTime = due
	task.Title = title
	task.Done = false
	task.UserId = -1
	var data hearxproto.CreateRequest
	data.UserId = userId
	data.Data = &task
	client := hearxproto.NewTodoServiceClient(conn)

	resp, err := client.AddTask(context.Background(), &data)
	return resp, err
}
