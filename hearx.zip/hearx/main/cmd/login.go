package cmd

import (
	"context"
	"fmt"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"google.golang.org/grpc"
	"hearx/example/hearxproto"
)

var (
	Email    string
	Password string
)

// loginCmd represents the login command
var loginCmd = &cobra.Command{
	Use:   "login",
	Short: "login with your credentials (login --email email --password pass)",
	Long:  `login with your credentials the Token received is necessary for all Todo/Tasks commands`,
	Run: func(cmd *cobra.Command, args []string) {
		resp, err := Login(Email, Password)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Printf("Response: %s-%s\n", resp.Base, resp.Token)
	},
}

func init() {
	rootCmd.AddCommand(loginCmd)

	loginCmd.Flags().StringVarP(&Email, "email", "e", "", "email to login as")
	loginCmd.Flags().StringVarP(&Password, "password", "p", "", "password to login as")
	_ = loginCmd.MarkFlagRequired("email")
	_ = loginCmd.MarkFlagRequired("password")
}

func Login(email string, password string) (*hearxproto.AuthResponse, error) {
	opts := grpc.WithInsecure()
	conn, err := grpc.Dial(Cfg.HearXServer, opts)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	client := hearxproto.NewAuthServiceClient(conn)
	request := &hearxproto.AuthRequest{Email: email, Password: password, FullName: ""}

	resp, err := client.Login(context.Background(), request)
	return resp, err
}
