package cmd

import (
	"context"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"go.uber.org/fx"
	"google.golang.org/grpc"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"hearx/example/hearxproto"
	"hearx/example/hrpc"
	"hearx/example/models"
	"net"
)

// serverCmd represents the server command
var serverCmd = &cobra.Command{
	Use:   "server",
	Short: "Start the grpc server. This command does not return",
	Long:  `start the grpc server. This command does not return`,
	Run: func(cmd *cobra.Command, args []string) {
		fx.New(
			fx.Provide(NewGRPCServer),
			fx.Invoke(func(*grpc.Server) {}),
		).Run()
	},
}

func NewGRPCServer(lc fx.Lifecycle) *grpc.Server {
	gs := grpc.NewServer()
	lc.Append(fx.Hook{
		OnStart: func(ctx context.Context) error {
			db := InitDb()
			lp, err := net.Listen("tcp", Cfg.HearXServer)
			if err != nil {
				return err
			}

			as := hrpc.AuthServer{DB: db, Cfg: Cfg}
			ts := hrpc.TaskServer{DB: db, Cfg: Cfg}

			hearxproto.RegisterAuthServiceServer(gs, &as)
			hearxproto.RegisterTodoServiceServer(gs, &ts)

			go func() {
				if err := gs.Serve(lp); err != nil {
					log.Info("Failed to run grp server ", err)
				}
			}()

			return nil
		},
		OnStop: func(ctx context.Context) error {
			log.Info("Gracefully stopping gRPC server")
			gs.GracefulStop()
			return nil
		},
	})
	return gs
}

func InitDb() *gorm.DB {
	dsn := Cfg.MysqlDSN
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatal("Could not find DB ", dsn)
	}

	db.AutoMigrate(&models.User{})
	db.AutoMigrate(&models.Task{})

	return db
}

func init() {
	rootCmd.AddCommand(serverCmd)
}
