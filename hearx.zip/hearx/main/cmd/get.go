package cmd

import (
	"context"
	"fmt"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"google.golang.org/grpc"
	"hearx/example/hearxproto"
)

var (
	Token string
)

// getCmd represents the get command
var getCmd = &cobra.Command{
	Use:   "get",
	Short: "returns a list of uncompleted tasks from server",
	Long:  `returns a list of uncompleted tasks from server`,
	Run: func(cmd *cobra.Command, args []string) {
		resp, err := GetTasks(Token)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println("======== LISTING =========")
		for i := 0; i < len(resp.Tasks); i++ {
			fmt.Printf("%d:- Title:'%s' Due:%d Done:%v\n",
				resp.Tasks[i].Id, resp.Tasks[i].Title,
				resp.Tasks[i].DueTime, resp.Tasks[i].Done)
		}
		fmt.Println("===========================")
	},
}

func init() {
	clientCmd.AddCommand(getCmd)

	getCmd.Flags().StringVarP(&Token, "token", "t", "", "-t HearX-Token")
	_ = getCmd.MarkFlagRequired("token")
}
func GetTasks(userid string) (*hearxproto.ListResponse, error) {
	opts := grpc.WithInsecure()
	conn, err := grpc.Dial(Cfg.HearXServer, opts)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	var data hearxproto.ListRequest
	data.UserId = userid
	client := hearxproto.NewTodoServiceClient(conn)

	resp, err := client.GetTasks(context.Background(), &data)
	return resp, err
}
