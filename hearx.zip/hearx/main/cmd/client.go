package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
)

// clientCmd represents the client command
var clientCmd = &cobra.Command{
	Use:   "client",
	Short: "root command to exec client side commands.",
	Long:  `root command to exec client side commands.`,
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("client called. but did you mean to give me more options (register, login, add, delete, complete or get)s")
	},
}

func init() {
	rootCmd.AddCommand(clientCmd)

}
