package cmd

import (
	"context"
	"fmt"
	log "github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"google.golang.org/grpc"
	"hearx/example/hearxproto"
)

var (
	FullName string
)

// registerCmd represents the register command
var registerCmd = &cobra.Command{
	Use:   "register",
	Short: "register with your credentials (register  --fullName full_name --email email --password pass)",
	Long:  `register with your credentials the Token received is necessary for all Todo/Tasks commands`,
	Run: func(cmd *cobra.Command, args []string) {
		resp, err := Register(Email, Password, FullName)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Printf("Response: %s-%s\n", resp.Base, resp.Token)
	},
}

func init() {
	rootCmd.AddCommand(registerCmd)
	registerCmd.Flags().StringVarP(&FullName, "fullName", "f", "", "Full name")
	registerCmd.Flags().StringVarP(&Email, "email", "e", "", "email to login as")
	registerCmd.Flags().StringVarP(&Password, "password", "p", "", "password to login as")
	_ = registerCmd.MarkFlagRequired("email")
	_ = registerCmd.MarkFlagRequired("password")
	_ = registerCmd.MarkFlagRequired("fullName")
}

func Register(email string, password string, fullName string) (*hearxproto.AuthResponse, error) {
	opts := grpc.WithInsecure()
	conn, err := grpc.Dial(Cfg.HearXServer, opts)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	client := hearxproto.NewAuthServiceClient(conn)
	request := &hearxproto.AuthRequest{Email: email, Password: password, FullName: fullName}

	resp, err := client.Register(context.Background(), request)
	return resp, err
}
