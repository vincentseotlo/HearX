package routes

import (
	"github.com/gin-gonic/gin"
	"hearx/example/controllers"
	"hearx/example/service"
)

// AddAuthRoutes is for making available login and registration of users
func AddAuthRoutes(auth *gin.RouterGroup) {
	svc := service.NewAuthService("auth service")
	controller := controllers.NewAuth(svc)

	auth.POST("/login", controller.Login)
	auth.POST("/register", controller.Register)
}
