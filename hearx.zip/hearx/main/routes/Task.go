package routes

import (
	"github.com/gin-gonic/gin"
	"hearx/example/controllers"
	"hearx/example/service"
)

// AddTasksRoutes add all task manipulation endpoints
func AddTasksRoutes(task *gin.RouterGroup) {

	svc := service.NewTaskService("task service")
	controller := controllers.NewTask(svc)

	task.DELETE("/delete/:task_id", controller.Delete)
	task.GET("/get", controller.List)
	task.POST("/add", controller.Create)
	task.PUT("/complete", controller.Update)
}
