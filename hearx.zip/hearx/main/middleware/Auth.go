package middleware

import (
	"errors"
	"github.com/gin-gonic/gin"
	"net/http"
	"strings"
)

func getToken(header string) (string, error) {
	if header == "" {
		return "", errors.New("bad header value given")
	}

	token := strings.Split(header, "-")
	if token[0] != "HearX" {
		return "", errors.New("incorrectly formatted authorization header")
	}

	return header, nil
}

// AuthCheck availability of token before bothering to communicate with gRPC
func AuthCheck(c *gin.Context) {
	token, err := getToken(c.GetHeader("HearXAuthToken"))

	if err != nil {
		c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
			"Message": err.Error(),
		})
		return
	}

	c.Set("auth_id", token)

	c.Next()
}
