package hrpc

import (
	"context"
	log "github.com/sirupsen/logrus"
	"gorm.io/gorm"
	"hearx/example/hearxproto"
	"hearx/example/models"
	"time"
)

type TaskServer struct {
	DB  *gorm.DB
	Cfg *models.Config
	hearxproto.AuthServiceServer
}

func (ts *TaskServer) TokenToUserId(token string) (int64, error) {
	var user models.User

	resp := ts.DB.First(&user, " token = ?", token[6:])
	if resp.Error != nil || user.TokenExpires < time.Now().Unix() {
		log.Debug("Unauthorised user")
		return -1, resp.Error
	}

	return user.Id, nil
}

// AddTask creates a new task, given the data
func (ts *TaskServer) AddTask(ctx context.Context, req *hearxproto.CreateRequest) (*hearxproto.StatusResponse, error) {
	userId, err := ts.TokenToUserId(req.UserId)
	if err != nil {
		return nil, err
	}
	var task models.Task
	task.Title = req.Data.Title
	task.UserId = userId
	task.DueTime = req.Data.DueTime
	task.Done = req.Data.Done

	log.Debug("creating task ", task.Title)

	resp := ts.DB.Create(&task)
	if resp.Error != nil {
		return nil, resp.Error
	}

	var res hearxproto.StatusResponse
	res.Status = true

	return &res, nil
}

// CompleteTask or mark complete
func (ts *TaskServer) CompleteTask(ctx context.Context, req *hearxproto.TaskRequest) (*hearxproto.StatusResponse, error) {
	userId, err := ts.TokenToUserId(req.UserId)
	if err != nil {
		return nil, err
	}

	var task models.Task

	resp := ts.DB.First(&task, "id = ? and user_id = ?", req.TaskId, userId)
	if resp.Error != nil {
		return nil, resp.Error
	}

	task.UserId = userId
	task.Done = true

	log.Debug("updating task ", task.Title)

	resp = ts.DB.Model(&task).Updates(&task)
	if resp.Error != nil {
		return nil, resp.Error
	}

	var res hearxproto.StatusResponse
	res.Status = true

	return &res, nil
}

// DeleteTask or mark deleted
func (ts *TaskServer) DeleteTask(ctx context.Context, req *hearxproto.TaskRequest) (*hearxproto.StatusResponse, error) {
	userId, err := ts.TokenToUserId(req.UserId)
	if err != nil {
		return nil, err
	}
	var task models.Task
	resp := ts.DB.First(&task, "id = ? and user_id = ?", req.TaskId, userId)
	if resp.Error != nil {
		return nil, resp.Error
	}

	log.Debug("deleting task ", task.Title)

	resp = ts.DB.Delete(&task, req.TaskId)
	if resp.Error != nil {
		return nil, resp.Error
	}

	var res hearxproto.StatusResponse
	res.Status = true

	return &res, nil
}

// GetTasks retrieves all tasks mot marked as complete
func (ts *TaskServer) GetTasks(ctx context.Context, req *hearxproto.ListRequest) (*hearxproto.ListResponse, error) {

	var list hearxproto.ListResponse
	userId, err := ts.TokenToUserId(req.UserId)
	if err != nil {
		return nil, err
	}
	rows, err := ts.DB.Model(&models.Task{}).Where("user_id = ? and done = false", userId).Rows()
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var task hearxproto.Task
		ts.DB.ScanRows(rows, &task)
		list.Tasks = append(list.Tasks, &task)
	}
	return &list, nil
}
