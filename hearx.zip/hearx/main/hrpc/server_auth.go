package hrpc

import (
	"context"
	"github.com/google/uuid"
	log "github.com/sirupsen/logrus"
	"gorm.io/gorm"
	"hearx/example/hearxproto"
	"hearx/example/models"
	"time"
)

type AuthServer struct {
	DB  *gorm.DB
	Cfg *models.Config
	hearxproto.AuthServiceServer
}

// Register a new user
func (s *AuthServer) Register(ctx context.Context, req *hearxproto.AuthRequest) (*hearxproto.AuthResponse, error) {
	var user models.User
	user.Password = req.Password
	user.FullName = req.FullName
	user.Email = req.Email
	token, _ := uuid.NewUUID()
	user.Token = token.String()
	user.TokenExpires = time.Now().Unix() + 3600

	resp := s.DB.Create(&user)
	if resp.Error != nil {
		return nil, resp.Error
	}
	var res hearxproto.AuthResponse
	res.Base = "HearX"
	res.Token = user.Token
	res.UserId = user.Id

	log.Debug("Created user ", res.UserId)

	return &res, nil
}

// Login an existing user
func (s *AuthServer) Login(ctx context.Context, req *hearxproto.AuthRequest) (*hearxproto.AuthResponse, error) {
	var user models.User
	resp := s.DB.First(&user, "email = ? and password = ?", req.Email, req.Password)
	if resp.Error != nil {
		return nil, resp.Error
	}
	token, _ := uuid.NewUUID()
	user.Token = token.String()
	user.TokenExpires = time.Now().Unix() + 3600

	log.Debug("user logged in", user.Email)

	s.DB.Model(&user).Updates(models.User{Token: user.Token, TokenExpires: user.TokenExpires})

	var res hearxproto.AuthResponse
	res.Base = "HearX"
	res.Token = user.Token
	res.UserId = user.Id
	return &res, nil
}

func (s *AuthServer) mustEmbedUnimplementedAuthServiceServer() {
	// do nothing
}
