/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>

*/
package main

import "hearx/example/cmd"

func main() {
	cmd.Execute()
}
