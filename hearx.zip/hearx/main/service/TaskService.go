package service

import (
	"encoding/json"
	log "github.com/sirupsen/logrus"
	"hearx/example/cmd"
	"hearx/example/models"
)

func (ts TaskServiceImpl) Create(userId string, data models.Task) error {
	d, _ := json.Marshal(data)
	log.Debug("create ", string(d))
	_, err := cmd.AddTask(userId, data.Title, data.DueTime)
	if err != nil {
		return err
	}
	return nil
}

func (ts TaskServiceImpl) Delete(userId string, taskId int64) error {
	log.Debug("delete", taskId)
	_, err := cmd.DeleteTask(userId, taskId)
	if err != nil {
		return err
	}
	return nil
}

func (ts TaskServiceImpl) List(userId string) ([]models.Task, error) {
	log.Debug("list")
	var tasks []models.Task
	resp, err := cmd.GetTasks(userId)
	if err != nil {
		return nil, err
	}
	for i := 0; i < len(resp.Tasks); i++ {
		var task models.Task
		task.Title = resp.Tasks[i].Title
		task.Done = resp.Tasks[i].Done
		task.Id = resp.Tasks[i].Id
		task.DueTime = resp.Tasks[i].DueTime
		tasks = append(tasks, task)
	}
	return tasks, nil
}

func (ts TaskServiceImpl) Update(userId string, data models.Task) error {
	d, _ := json.Marshal(data)
	log.Debug("update", string(d))
	_, err := cmd.CompleteTask(userId, data.Id)
	if err != nil {
		return err
	}
	return nil
}

func NewTaskService(name string) *TaskServiceImpl {
	log.SetLevel(log.DebugLevel)
	return &TaskServiceImpl{
		svc: name,
	}
}
