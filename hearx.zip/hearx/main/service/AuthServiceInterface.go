package service

import "hearx/example/models"

type AuthService interface {
	Login(data models.User) (*models.HearXToken, error)
	Register(data models.User) error
}

type AuthServiceImpl struct {
	svc string
}
