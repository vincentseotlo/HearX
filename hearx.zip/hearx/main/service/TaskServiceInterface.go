package service

import "hearx/example/models"

type TaskService interface {
	Create(userId string, data models.Task) error
	Delete(userId string, taskId int64) error
	List(userId string) ([]models.Task, error)
	Update(userId string, data models.Task) error
}

type TaskServiceImpl struct {
	svc string
}
