package service

import (
	"encoding/json"
	log "github.com/sirupsen/logrus"
	"hearx/example/cmd"
	"hearx/example/models"
)

func (as AuthServiceImpl) Login(data models.User) (*models.HearXToken, error) {
	d, _ := json.Marshal(data)
	log.Debug("login", string(d))

	resp, err := cmd.Login(data.Email, data.Password)
	if err != nil {
		return nil, err
	}

	ret := models.HearXToken{Token: resp.Token, Base: resp.Base, UserId: resp.UserId}

	return &ret, nil
}

func (as AuthServiceImpl) Register(data models.User) error {
	d, _ := json.Marshal(data)
	log.Debug("register", string(d))

	_, err := cmd.Register(data.Email, data.Password, data.FullName)
	if err != nil {
		return err
	}

	return nil
}

func NewAuthService(svc string) *AuthServiceImpl {
	log.SetLevel(log.DebugLevel)
	return &AuthServiceImpl{
		svc: svc,
	}
}
