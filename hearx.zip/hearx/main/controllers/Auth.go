package controllers

import (
	"github.com/gin-gonic/gin"
	"hearx/example/models"
	"hearx/example/service"
	"net/http"
)

// Login into the system and get back an auth token
func (a AuthInterfaceImpl) Login(c *gin.Context) {
	var data models.User
	if err := c.BindJSON(&data); err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"Message": err.Error()})
		return
	}
	token, err := a.svc.Login(data)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"Message": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"Token": token.Base + "-" + token.Token})
}

// Register a user
func (a AuthInterfaceImpl) Register(c *gin.Context) {
	var data models.User
	if err := c.BindJSON(&data); err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"Message": err.Error()})
		return
	}

	err := a.svc.Register(data)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"Message": err.Error()})
		return
	}

	c.JSON(http.StatusOK, "register")
}

func NewAuth(svc service.AuthService) *AuthInterfaceImpl {
	return &AuthInterfaceImpl{
		svc: svc,
	}
}
