package controllers

import (
	"github.com/gin-gonic/gin"
	"hearx/example/models"
	"hearx/example/service"
	"net/http"
	"strconv"
)

func getAuthId(c *gin.Context) string {
	authId := c.GetString("auth_id")
	return authId
}

// Create or add a task
func (t TaskInterfaceImpl) Create(c *gin.Context) {
	authId := getAuthId(c)
	var data models.Task

	if err := c.BindJSON(&data); err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"Message": err.Error()})
		return
	}
	err := t.svc.Create(authId, data)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"Message": err.Error()})
	}
	c.JSON(http.StatusOK, gin.H{"Message": "Create"})
}

// Delete (mark task deleted)
func (t TaskInterfaceImpl) Delete(c *gin.Context) {

	authId := getAuthId(c)

	taskIdString := c.Param("task_id")
	taskId, err := strconv.ParseInt(string(taskIdString), 0, 64)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"Message": err.Error()})
		return
	}

	err = t.svc.Delete(authId, taskId)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"Message": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"Message": "Delete"})
}

// List or get all uncompleted tasks
func (t TaskInterfaceImpl) List(c *gin.Context) {
	authId := getAuthId(c)

	list, err := t.svc.List(authId)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"Message": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": list})
}

// Update or mark task done
func (t TaskInterfaceImpl) Update(c *gin.Context) {
	authId := getAuthId(c)
	var data models.Task

	if err := c.BindJSON(&data); err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"Message": err.Error()})
		return
	}
	err := t.svc.Update(authId, data)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"Message": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"Message": "Update"})
}

func NewTask(svc service.TaskService) *TaskInterfaceImpl {
	return &TaskInterfaceImpl{
		svc: svc,
	}
}
