package controllers

import (
	"github.com/gin-gonic/gin"
	"hearx/example/service"
)

type TaskInterface interface {
	Create(c *gin.Context)
	Delete(c *gin.Context)
	List(c *gin.Context)
	Update(c *gin.Context)
}

type TaskInterfaceImpl struct {
	svc service.TaskService
}
