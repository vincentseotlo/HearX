package controllers

import (
	"github.com/gin-gonic/gin"
	"hearx/example/service"
)

type AuthController interface {
	Login(c *gin.Context)
	Register(c *gin.Context)
}

type AuthInterfaceImpl struct {
	svc service.AuthService
}
